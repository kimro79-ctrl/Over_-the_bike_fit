import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(OverTheBikeFitApp());

class OverTheBikeFitApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Over the Bike Fit",
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        colorScheme: const ColorScheme.dark(primary: Color(0xFFFF3B3B)),
      ),
      home: SplashScreen(),
    );
  }
}

// ========================= 스플래시 화면 =========================
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => SlideHome()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/splash.png', width: 180),
            const SizedBox(height: 20),
            const Text(
              "Over the Bike Fit",
              style: TextStyle(
                fontSize: 22,
                color: Color(0xFFFF3B3B),
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ========================= 메인 홈 =========================
class SlideHome extends StatefulWidget {
  @override
  State<SlideHome> createState() => _SlideHomeState();
}

class _SlideHomeState extends State<SlideHome> {
  PageController controller = PageController();
  int seconds = 0;
  int heartRate = 72;
  int targetTime = 20 * 60;
  bool isRunning = false;
  Timer? timer;
  Timer? hrTimer;
  List<int> heartRateData = [];
  List<String> records = [];

  @override
  void initState() {
    super.initState();
    startHeartRateSimulation();
  }

  @override
  void dispose() {
    timer?.cancel();
    hrTimer?.cancel();
    controller.dispose();
    super.dispose();
  }

  void startWorkout() {
    setState(() {
      isRunning = true;
      timer = Timer.periodic(
          const Duration(seconds: 1), (_) => setState(() => seconds++));
    });
  }

  void stopWorkout() {
    timer?.cancel();
    setState(() => isRunning = false);
  }

  void resetWorkout() {
    timer?.cancel();
    setState(() {
      isRunning = false;
      seconds = 0;
    });
  }

  void saveSession() {
    final now = DateTime.now();
    final record =
        "📅 ${now.month}/${now.day}  ⏱ ${(seconds / 60).toStringAsFixed(1)}분  ❤️ $heartRate bpm";
    records.add(record);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text("운동 기록 저장 완료")));
    resetWorkout();
  }

  void startHeartRateSimulation() {
    hrTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        heartRate = 60 + Random().nextInt(40);
        heartRateData.add(heartRate);
        if (heartRateData.length > 20) heartRateData.removeAt(0);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: controller,
        children: [
          _homePage(),
          _recordPage(),
          _goalPage(),
        ],
      ),
    );
  }

  // ========================= 홈 화면 =========================
  Widget _homePage() {
    final min = (seconds ~/ 60).toString().padLeft(2, '0');
    final sec = (seconds % 60).toString().padLeft(2, '0');
    final progress = (seconds / targetTime).clamp(0.0, 1.0);

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 50),
          Image.asset('assets/icon.png', width: 80),
          const SizedBox(height: 10),
          const Text("홈 화면",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 15),
          _infoTile("심박수", "$heartRate bpm", 'assets/heart.png'),
          _simpleHeartRateGraph(),
          _infoTile("운동시간", "$min:$sec", 'assets/timer.png'),
          _infoTile("목표시간", "${targetTime ~/ 60}분", 'assets/flag.png'),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: Colors.grey[850],
              color: const Color(0xFFFF3B3B),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _roundButton(isRunning ? "정지" : "시작",
                  isRunning ? stopWorkout : startWorkout),
              _roundButton("리셋", resetWorkout),
              _roundButton("저장", !isRunning && seconds > 0 ? saveSession : null),
            ],
          ),
          const Spacer(),
          const Text("← 슬라이드로 기록 / 목표시간 이동 →",
              style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ========================= 기록 화면 =========================
  Widget _recordPage() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 50),
          const Text("운동 기록",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Expanded(
            child: records.isEmpty
                ? const Center(child: Text("저장된 기록이 없습니다."))
                : ListView.builder(
                    itemCount: records.length,
                    itemBuilder: (context, i) => ListTile(
                      leading:
                          const Icon(Icons.fitness_center, color: Colors.redAccent),
                      title: Text(records[i]),
                    ),
                  ),
          ),
          const Text("← / → 슬라이드로 이동", style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ========================= 목표 설정 =========================
  Widget _goalPage() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 50),
          const Text("목표시간 설정",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.remove, color: Colors.redAccent),
                onPressed: () {
                  setState(() {
                    if (targetTime > 60) targetTime -= 60;
                  });
                },
              ),
              Text("${targetTime ~/ 60}분",
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              IconButton(
                icon: const Icon(Icons.add, color: Colors.redAccent),
                onPressed: () => setState(() => targetTime += 60),
              ),
            ],
          ),
          const Spacer(),
          const Text("← / → 슬라이드로 이동", style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ========================= 재사용 위젯 =========================
  Widget _infoTile(String title, String value, String assetPath) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Image.asset(assetPath, width: 28, height: 28, color: Colors.redAccent),
          const SizedBox(width: 15),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 16))),
          Text(value,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _simpleHeartRateGraph() {
    return SizedBox(
      height: 120,
      child: CustomPaint(
        painter: HeartRatePainter(heartRateData),
        child: Container(),
      ),
    );
  }

  Widget _roundButton(String label, VoidCallback? onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFFFF3B3B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 14),
      ),
      onPressed: onPressed,
      child: Text(label, style: const TextStyle(fontSize: 16, color: Colors.white)),
    );
  }
}

class HeartRatePainter extends CustomPainter {
  final List<int> data;
  HeartRatePainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.redAccent
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    if (data.isEmpty) return;

    final path = Path();
    final dx = size.width / (data.length - 1);
    for (int i = 0; i < data.length; i++) {
      final x = i * dx;
      final y = size.height - ((data[i] - 50) / 100 * size.height);
      if (i == 0)
        path.moveTo(x, y);
      else
        path.lineTo(x, y);
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant HeartRatePainter oldDelegate) => true;
}